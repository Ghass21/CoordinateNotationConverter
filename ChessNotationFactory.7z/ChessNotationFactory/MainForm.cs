﻿/*
 * Created by SharpDevelop.
 * User: Ghass
 * Date: 06/08/2018
 * Time: 13:05
 * 
  */
 
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace ChessNotationFactory
{
	
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public int[,] chessBoard = new int [, ] {{2, 3, 4, 5, 6, 4, 3, 2},{1, 1, 1, 1, 1, 1, 1, 1}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {-1, -1, -1, -1, -1, -1, -1, -1} , {-2, -3, -4, -5, -6, -4, -3, -2}};
		// "c2c4g7g6b1c3c7c5g2g3b8c6f1g2f8g7e2e3d7d6g1e2e7e5e1g1c8e6c3d5g8e7h2h3e8g8d2d3a8b8a1b1b7b5b2b3a7a5f2f4a5a4g1h2a4b3a2b3b5c4d3c4e6d5c4d5c6b4e3e4b8a8f4f5f7f6c1d2g6f5d2b4c5b4e4f5a8a2g3g4g7h6h2h1d8b6e2g3f8c8g3e4c8c2g4g5h6g5f1g1e7f5d1g4f5e3e4f6g8f7g4e6f7g6f6d7g6h5d7b6e3g2e6g4h5h6g1g2" ;		
		// "e2e4b7b6e4e5d7d5e5d6d8d6f2f4g7g5f4f5g5g4h2h4g4h3b1h3d6g3" ;
		public String pgnGame;
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
//----------------------------------------------------------		
		void Button1Click(object sender, EventArgs e)
		{
			String res, ch, game, s;

			int i, j,z, a, b, x1, x2, y1, y2;
			
			pgnGame = richTextBox1.Text;
			pgnGame = " " + pgnGame + " ";
			game = pgnGame;
			s = game;
							
			for(i=1; i<pgnGame.Length/13+1; i++) {
				s = s.Replace(" " + i.ToString() + ".","");
			}
	
			res = s.Replace(" ","");
			
			ch = res;
			res = res.Replace('a', '1').Replace('b','2').Replace('c','3').Replace('d','4').Replace('e','5').Replace('f','6').Replace('g','7').Replace('h','8');
			game = "";
			
			String piece = "";
			for(i=0; i<ch.Length/4; i++)
			{
				z = i % 2;
				if (z == 0)
				{
					j = (i/2) + 1;
					game = game + " " + j + ". ";
				}
				
				x1 = res[4*i]-49;
				y1 = res[4*i+1]-49;
				x2 = res[4*i+2]-49;
				y2 = res[4*i+3]-49;
				if ( (chessBoard[y1,x1]==1) || (chessBoard[y1,x1]== -1)) 	{ //Pawn
					a = res[4*i];
					b = res[4*i+1];
					
					if (x1 != x2) {	// Pawn capture 
						game = game + ch[4*i] + "x" + ch[4*i+2] + ch[4*i+3] + " ";
						if (ch[4*i+3]==8) {} 
						// pawn promotion and capture .. not implemented
						// Check ... 
					}
					else {	// Pawn move
						game = game + ch[4*i] + ch[4*i+3] + " ";
						if (ch[4*i+3]==8) { }
						
						// pawn promotion ... not implemented
						// Check ... not implemented
						}
				}
				else {
					// Check ...
					// Identical pieces can move to the same square ... not implemented
					
					a = res[4*i];
					b = res[4*i+1];
					
					switch (Math.Abs(chessBoard[y1,x1])) {
						case 2:
							piece = "R";
							break;
						case 3:
							piece = "N";
							break;
						case 4:
							piece = "B";
							break;
						case 5:
							piece = "Q";
							break;
						case 6:
							piece = "K";
							break;
					}
					
					if (piece=="K") {
						if ((x1 - x2)*(x1 - x2) == 4) {
							game = game + "0-0 ";
						}
						else {
							if (chessBoard[y2,x2]!=0 )	{
								game = game + piece + "x" + ch[4*i+2] + ch[4*i+3] + " ";
							}
							else {
								game = game + piece + ch[4*i+2] + ch[4*i+3] + " ";
							}
						}
					}
					else if (chessBoard[y2,x2]!=0 ) {
						game = game + piece + "x" + ch[4*i+2] + ch[4*i+3] + " ";
					}
					else	{
						game = game + piece + ch[4*i+2] + ch[4*i+3] + " ";
					}
				}
				// Piece movement on the chessboard
				if (piece =="K") {
					if (x2 - x1 == 2)	{
						chessBoard[y2,x2] = chessBoard[y1,x1]; // 0-0
						chessBoard[y1,x1] = 0;
						chessBoard[y2,x2-1] = chessBoard[y2,x2+1];
						chessBoard[y2,x2+1] = 0;
					}
					else if (x2 - x1== -2)	{
						chessBoard[y2,x2] = chessBoard[y1,x1]; // 0-0-0
						chessBoard[y1,x1] = 0;
						chessBoard[y2,x2+1] = chessBoard[y2,x2-1];
						chessBoard[y2,x2-1] = 0;
					}
					else  {
						chessBoard[y2,x2] = chessBoard[y1,x1];
						chessBoard[y1,x1] = 0;
					}
				}
				else  {
					if ((chessBoard[y1,x1] == 1) && (chessBoard[y2,x2] == 0) && (x1!=x2)) {
						//En passant capture
						chessBoard[y2+1,x2] = 0;						
					}
					else
						if ((chessBoard[y1,x1] == -1) && (chessBoard[y2,x2] == 0) && (x1!=x2)) {
							//En passant capture
							chessBoard[y2-1,x2] = 0;						
							}			
							
						chessBoard[y2,x2] = chessBoard[y1,x1];
						chessBoard[y1,x1] = 0;
				}
			}
			
			richTextBox2.Text = game;

		}
//----------------------------------------------------------------		
bool Check(int x, int y, int xR, int yR) // not yet
{
	switch (chessBoard[y,x])
					{
						case 1:
							if ( ((x == xR) && (y == yR + 1)) || ((x == xR) && (y == yR + 1)) ) 
							return(true);
							break;
						case 2:
							return(true);
						case 3:
							return(true);
						case 4:
							return(true);
						case 5:
							return(true);
						case 6:
							return(true);
					}
	
	return(false);
}
//----------------------------------------------------------------
	}
}
